# estrutura-de-dados-c

Projeto em C para comparação de algoritmos de busca (sequencial e binária) com análise estatística de desempenho.

## Estrutura do projeto

```
estrutura-de-dados-c/
├── main.c                        # Ponto de entrada do programa
├── Makefile                      # Compilação
├── .gitignore
├── q_1_aed/                      # Questão 1 — Busca em vetor
│   ├── programa.h                # Cabeçalhos das funções
│   ├── busca.c                   # Busca sequencial e busca binária
│   ├── vetor.c                   # Criação de vetores (aleatório e ordenado)
│   ├── estatisticas.c            # Cálculo de média e desvio padrão
│   └── resolveq1.c               # Benchmark: vetor vs busca binária (30 rodadas)
└── q_2_aed/                      # Questão 2 — Busca em lista encadeada
    ├── TADlista.h                # TAD da lista encadeada
    ├── busca_sequencial.c        # Inserção e busca na lista
    └── questao_2.c               # Benchmark: vetor vs lista encadeada (60 rodadas)
```

## Como compilar e executar

```bash
make
./programa
```

Para limpar o executável:

```bash
make clean
```

## Funcionalidades

### Questão 1
- **Busca Sequencial em vetor** — percorre o vetor elemento por elemento
- **Busca Binária em vetor ordenado** — divide o intervalo pelo meio a cada passo
- 30 rodadas com análise estatística (média e desvio padrão)

### Questão 2
- **Busca Sequencial em vetor** vs **Busca Sequencial em lista encadeada**
- 60 rodadas (30 para cada estrutura) com análise estatística

## Dependências

- GCC
- `math.h` (flag `-lm` já inclusa no Makefile)
